﻿using System;

namespace Renovators
{
    public class StartUp
    {
        static void Main()
        {
            
        }
    }
}
